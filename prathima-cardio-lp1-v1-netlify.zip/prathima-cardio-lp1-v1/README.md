# Prathima Hospitals – Cardiology / Kukatpally LP1 (v1)

Netlify-ready static landing page for the Google Ads cardiology pilot.

## Included
- Desktop + responsive mobile layout matching the approved design direction
- Exact doctor image supplied by the user
- Pilot phone number: 6304562164
- NABH text badge
- GMB rating block: 4.4 / 5 and 2,724 Google reviews (user-provided)
- Separate “What Makes Prathima Hospitals Different?” section
- Separate patient facilities section with standard rooms vs optional suite/premium stay
- GCLID / GBRAID / WBRAID + UTM hidden-field capture
- Appointment form validation and analytics event hooks
- No external font/icon library required

## Temporary visual assets
`hospital-placeholder.webp`, `standard-room-placeholder.webp`, and `suite-room-placeholder.webp` are cropped from the approved design reference only to match the requested visual layout. Replace them with approved real Prathima Hospitals facility photographs before production.

## Before launch
1. Replace exact Kukatpally address + approved Google Maps URL.
2. Replace placeholder WhatsApp URL if the pilot number is not WhatsApp-enabled.
3. Connect `appointmentForm` to the CRM/API/Netlify Function.
4. Add the approved Google Ads / GA4 tags.
5. Confirm the NABH certification wording/logo treatment with the hospital.
6. Verify and approve the “25+ years” and patient-recognition copy.

The page intentionally uses `noindex,nofollow` because it is designed for Google Ads rather than organic search.
